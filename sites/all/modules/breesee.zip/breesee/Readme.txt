

content_profile_edit.module
	Line 20 Original commented
	Line 21 Added
	
	Line 25 Original commented
	Line 26 Added
	
	
wysiwyg/wysiwyg.js
	Line 72-74 Commented
	
privatemsg/privatemsg.module
	Line 1424 Original Commented 
	Line 1425 Added
	
//	Line 1400 Original Commented 	//
//	Line 1401 Added  							//

wysiwyg_imageupload.module edited on  12/12/2011

wysiwyg_imageupload_nodeapi add this line 

Line 255 Added / $node->body = _wysiwyg_imageupload_filter_process($node->body); 

modalframe_example/modalframe_example.js
	Line 26 Added [avoid if commented
	
	
//////////////////// Roles Hardcoded


uc_cart.pages.inc line 448 function theme_uc_cart_checkout_review($panes, $form) {
