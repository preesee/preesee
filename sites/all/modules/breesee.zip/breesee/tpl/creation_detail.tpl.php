<?php 
$node = $data['creation_detail'];
//print_r($node);
?>
<div id="creation_detail_page">
<a id="backof" href="#" rel="<?php print $data['creation_detail']->uid; ?>">BACK</a>
<div class="creation_title"><h1><?php print $data['creation_detail']->title; ?></h1></div>
<div class="creation_body"><?php print $data['creation_detail']->body; ?>  </div>
<div class="creation_body"><?php print theme('imagecache', 'center_image', $data['creation_detail']->field_upload[0]['filepath']); ?> </div>
<div id="other_creations">
<?php print _breesee_othercreationfrom($data['creation_detail']->uid, $data['creation_detail']->nid, 'creations'); ?>
</div>
<div id="node_comments">
<?php print comment_render($node, $cid = 0); ?>
</div>
</div>