$(document).ready(function(){
		$('.tablerow').click(function() {
																	
																	
				var idofdiv = $(this).attr('id');
				//window.location.href = Drupal.settings.breesee.base_url + '/user/orderdetail/' + idofdiv;
				//return false;
				$('.login_purchaising_block_cover').css('display','none');
				$('div #' + idofdiv + 'div').css('display','block');
				$('div #' + idofdiv + 'div').html('<div class="preload"><br>Loading ...</div>');
				var atheUrl = Drupal.settings.breesee.base_url + '/user/orderdetail/' + idofdiv;
				$.ajax({
					url: atheUrl,
					success: function(msg){
						//console.log(msg);
						$('div #' + idofdiv + 'div').html(msg);
						init_self_close();
						init_igot_it();
						init_submit();
						
							
						
					}
				});
	
		});
		
});



function init_submit() {
		$('.feedback-button').click(function (e){
		  	e.preventDefault();
				
				
				var ser_frm = $('#breesee-purchase-feedback-form').serialize();
				var aj_url = Drupal.settings.breesee.base_url + '/user/feedback';
				$.ajax({method: "get",
					url: aj_url, 
					data: ser_frm,
					success: function(result) { 
					if(result == 'success')
						window.location.reload();
					else 
						return false;
					}
				});
				
				
		});
}

function init_self_close() {
	$('.closebtn').click(function() {
		$('.order_details').fadeOut('slow').queue(
		$('html, body').animate({scrollTop: '120px'}, 600));
	});
}

function init_igot_it() {
	jQuery('#igotit').click(function(e) {
		e.preventDefault();
		//jQuery('#gotitdiv').html('<div class="preloader">&nbsp;</div>');
			var oid = jQuery(this).attr('rel');
			var atheUrl = Drupal.settings.breesee.base_url + '/user/orderdetail/' + oid;
				var atheUrl = Drupal.settings.breesee.base_url + '/order/ostatus/' + oid;
				$.ajax({
					url: atheUrl,
					success: function(msg){
						//console.log(msg);]
						if(result == 'success')
							window.location.reload()
						else 
							return false;
					}
				});	
	});
}

function form_validate() {
		alert($("input[@name='feedback']").val());																					 
    if ($("input[@name='feedback']:checked").val() == '0')
         $('.message').text("Please select at least one!"); 
    else if ($("input[@name='feedback']:checked").val() == '1')
         $('.message').text("Please select at least one!"); 
    else
         $('.message').text("Please select at least one!"); 
		
}