$(document).ready(function(){
	$("ul.sidenavgation li.left").mouseenter(function() {
		$(this).find("div.inner_info").stop()
			.animate({left: "153", opacity:1}, "fast")
			.css("display","block")
		});
	$("ul.sidenavgation li.left").mouseleave(function() {
			$(this).find("div.inner_info").stop()
			.animate({left: "0", opacity: 0}, "fast")
	});	
	
		$("ul.sidenavgation li.right").mouseenter(function() {
		$(this).find("div.inner_info").stop()
			.animate({left: "-171", opacity:1}, "fast")
			.css("display","block")
		});
	$("ul.sidenavgation li.right").mouseleave(function() {
			$(this).find("div.inner_info").stop()
			.animate({left: "0", opacity: 0}, "fast")
	});	
	
});


/*	$(".inner_info").click(function() {
			$(this).fadeOut();
	});*/