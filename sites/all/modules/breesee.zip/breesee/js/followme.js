$(document).ready(function() {
	$('#followers').html('<div class="preload"><br>Loading ...</div>');
	var tofollow = $('#followme').attr('rel');
	var theUrl = base_url + '/myfollowers/' + tofollow;
	$.ajax({
							url: theUrl,
							success: function(msg){		
							$('#followers').html(msg);	
							}
	});
	$('#followmediv').mouseenter(function () {
		//alert('l');
		$('#ftxt').html('Follow Me');
		//$('#ftxt').css('background', '#09F');
	});
	$('#followmediv').mouseleave(function () {
		var bg = $('#ftxt').css('background');
		if (bg != 'none repeat scroll 0% 0% rgb(0, 204, 51)' )
			//$('#ftxt').css('background', '#0C3');
			$('#ftxt').html('Followers');
	});
	$('#followmediv').click(function () {
		var tofollow = $('#followme').attr('rel');
					if (!isNaN(tofollow)) {
					$('#followers').html('<div class="preload"><br>Refreshing ...</div>');
					var tofollow = $('#followme').attr('rel');
					var theUrl = base_url + '/userfollow/' + tofollow;
					$.ajax({
										url: theUrl,
										success: function(msg){		
										$('#ftxt').html(msg);
										var tofollow = $('#followme').attr('rel');
										var theUrl = base_url + '/myfollowers/' + tofollow;
										$.ajax({
											url: theUrl,
											success: function(msg){		
												$('#followers').html(msg);	
												addCount();
											}
										});
										}
										});
					$('#ftxt').html('Following');
					$('#followmediv').css('background-position', 'left -74px');
					}
	});
	
/*	$('#contact_me').click(function() {
		var uid = $(this).attr('rel');
		$('#homeblog .quicktabs_tabs').append('<li id="contact_load"><a>Contact</a></li>');
		$('#homeblog .quicktabs_tabs').append('<li id="contact_load"><a>Contact</a></li>');
	});*/
	
});

function addCount() {
	var precnt = $('#folow_count').text();
	var new_cnt = parseInt(precnt) + 1;
	$('#folow_count').text(new_cnt);
}

/*  http://jscompress.com/
function addCount(){var a=$("#folow_count").text();var b=parseInt(a)+1;$("#folow_count").text(b)}$(document).ready(function(){$("#followers").html('<div class="preload"><br>Loading ...</div>');var a=$("#followme").attr("rel");var b=base_url+"/myfollowers/"+a;$.ajax({url:b,success:function(a){$("#followers").html(a)}});$("#followmediv").mouseenter(function(){$("#ftxt").html("Follow Me");$("#ftxt").css("background","#09F")});$("#followmediv").mouseleave(function(){var a=$("#ftxt").css("background");if(a!="none repeat scroll 0% 0% rgb(0, 204, 51)")$("#ftxt").css("background","#0C3");$("#ftxt").html("Followers")});$("#followmediv").click(function(){var a=$("#followme").attr("rel");if(!isNaN(a)){$("#followers").html('<div class="preload"><br>Refreshing ...</div>');var a=$("#followme").attr("rel");var b=base_url+"/userfollow/"+a;$.ajax({url:b,success:function(a){$("#ftxt").html(a);var b=$("#followme").attr("rel");var c=base_url+"/myfollowers/"+b;$.ajax({url:c,success:function(a){$("#followers").html(a);addCount()}})}});$("#ftxt").html("Following");$("#ftxt").css("background","#0C3")}})})
*/