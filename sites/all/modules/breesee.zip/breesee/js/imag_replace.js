$(document).ready(function(){ 
													 
	  $('.thumbnail_product li a').click(function(e) {
			$('.display_product').fadeIn();
			e.preventDefault();
			var newimgsrc = $(this).attr('rel');
			$('#prod_big').attr("src",newimgsrc);
		});
		
		$('.colour_scheme li').click(function(e) {
			e.preventDefault();
			$('.node-add-to-cart').css("opacity", 0.3);
			$('.colour_scheme li').removeClass('selected');
			$(this).addClass('selected');
			var color = rgb2hex($(this).css('background-color'));
			var nid = $(this).attr('id');
			var atheUrl = Drupal.settings.breesee.base_url + '/order/color/' + color + '/' + nid;
			$.ajax({
				url: atheUrl,
				success: function(msg){
					$('#chosecolor').fadeOut();
					$('.node-add-to-cart').css("opacity", 1);
				}
			});
			
			
		});
		
		$('.node-add-to-cart').click(function(e) {
			var mycount =  $('.selected').length;
			if(mycount == 0 ) {
				$('html, body').animate({scrollTop: '120px'}, 300);
				$('#chosecolor').fadeIn();
				$('.node-add-to-cart').css("opacity", 0.3);
				return false;
			}
			else {
				$('#chosecolor').fadeOut();
				$('.node-add-to-cart').css("opacity", 1);
				return true;
			}
		});
		
		
});

function rgb2hex(rgb){
 rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
 return ("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[3],10).toString(16)).slice(-2);
}