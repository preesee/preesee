$(document).ready(function() {
   // put all your jQuery goodness in here.
	 //alert('Already Requested Upgrade !!');
});